'use client';

import { useState } from 'react';
import StepAcademics from '@/components/StepAcademics';
import StepTechnicalSkills from '@/components/StepTechnicalSkills';
import StepExperience from '@/components/StepExperience';
import StepProjects from '@/components/StepProjects';
import StepCertifications from '@/components/StepCertifications';
import StepPreferences from '@/components/StepPreferences';
import ResultsLayout from '@/components/ResultsLayout';
import { calculatePlacementScore, defaultProfile, type Profile } from '@/lib/scoring';
import { validateProfile } from '@/lib/validation';

const steps = ['Academics','Technical Skills','Experience','Projects','Certifications','Preferences'];

export default function Home() {
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState<Profile>(defaultProfile);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const update = (patch: Partial<Profile>) => setProfile(p => ({ ...p, ...patch }));
  const next = () => { setError(''); if (step < steps.length - 1) setStep(s => s + 1); else { const e = validateProfile(profile); if (e.length) setError(e[0]); else setSubmitted(true); } };
  if (submitted) return <ResultsLayout profile={profile} result={calculatePlacementScore(profile)} onBack={() => setSubmitted(false)} />;

  return <main className="shell">
    <header className="topbar"><div className="brand">Placement<span>Predict</span></div><div className="progress-text">Step {step + 1} of {steps.length}</div></header>
    <section className="hero"><p className="eyebrow">CAREER READINESS ANALYZER</p><h1>Know your placement potential.</h1><p>Enter your academic, technical and career profile to generate a placement-readiness score and actionable improvement plan.</p></section>
    <nav className="stepper">{steps.map((name, i) => <button key={name} className={i === step ? 'active' : i < step ? 'done' : ''} onClick={() => i <= step && setStep(i)}><b>{i+1}</b><span>{name}</span></button>)}</nav>
    <section className="card form-card">
      {step === 0 && <StepAcademics profile={profile} update={update} />}
      {step === 1 && <StepTechnicalSkills profile={profile} update={update} />}
      {step === 2 && <StepExperience profile={profile} update={update} />}
      {step === 3 && <StepProjects profile={profile} update={update} />}
      {step === 4 && <StepCertifications profile={profile} update={update} />}
      {step === 5 && <StepPreferences profile={profile} update={update} />}
      {error && <p className="error">{error}</p>}
      <div className="actions"><button className="secondary" disabled={step===0} onClick={() => setStep(s=>s-1)}>Back</button><button className="primary" onClick={next}>{step === steps.length-1 ? 'Generate Placement Score' : 'Continue'}</button></div>
    </section>
  </main>;
}
