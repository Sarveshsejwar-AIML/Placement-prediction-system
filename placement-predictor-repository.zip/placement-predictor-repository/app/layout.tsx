import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Placement Predictor',
  description: 'Student placement readiness and career-fit analysis.'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
