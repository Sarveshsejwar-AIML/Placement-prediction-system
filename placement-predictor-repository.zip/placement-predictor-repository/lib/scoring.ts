export type Profile = {
  cgpa:number; backlog:number; aptitude:number; coding:number; communication:number;
  skills:string[]; internships:number; experienceMonths:number; projects:number; projectQuality:number;
  certifications:number; targetRole:string; preferredCompanies:string[];
};
export const defaultProfile: Profile = {cgpa:7.5,backlog:0,aptitude:60,coding:60,communication:60,skills:[],internships:0,experienceMonths:0,projects:1,projectQuality:60,certifications:0,targetRole:'Software Engineer',preferredCompanies:[]};
const clamp=(n:number,min=0,max=100)=>Math.max(min,Math.min(max,n));
export function calculatePlacementScore(p:Profile){
  const academics=clamp(p.cgpa/10*100 - p.backlog*8);
  const technical=clamp(p.coding*.65+p.aptitude*.2+p.skills.length*2+p.communication*.15);
  const experience=clamp(p.internships*18+p.experienceMonths*.7);
  const projects=clamp(p.projects*12+p.projectQuality*.35);
  const certifications=clamp(p.certifications*15);
  const overall=Math.round(academics*.25+technical*.30+experience*.15+projects*.20+certifications*.10);
  return {overall,breakdown:{academics:Math.round(academics),technical:Math.round(technical),experience:Math.round(experience),projects:Math.round(projects),certifications:Math.round(certifications)}};
}
