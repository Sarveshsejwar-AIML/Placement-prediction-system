import type { Profile } from './scoring';
export function validateProfile(p:Profile){const errors:string[]=[]; if(p.cgpa<0||p.cgpa>10) errors.push('CGPA must be between 0 and 10.'); if(p.backlog<0) errors.push('Backlogs cannot be negative.'); if(!p.targetRole) errors.push('Select a target role.'); return errors;}
