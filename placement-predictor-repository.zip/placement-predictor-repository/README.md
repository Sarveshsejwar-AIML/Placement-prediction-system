# Placement Predictor

A reconstructed Next.js + TypeScript repository based on the visible Placement Predictor interface and component/file structure supplied by the user.

## Run

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Structure

- `app/page.tsx` — application entry point
- `app/layout.tsx` — root layout
- `app/globals.css` — global UI styles
- `components/StepAcademics.tsx`
- `components/StepTechnicalSkills.tsx`
- `components/StepExperience.tsx`
- `components/StepProjects.tsx`
- `components/StepCertifications.tsx`
- `components/StepPreferences.tsx`
- `components/HeroScoreSection.tsx`
- `components/ScoreRingChart.tsx`
- `components/ScoreBreakdownSection.tsx`
- `components/PeerBenchmarkSection.tsx`
- `components/SkillGapsSection.tsx`
- `components/RecommendationsSection.tsx`
- `components/ImprovementTimeline.tsx`
- `components/ResultsLayout.tsx`
- `lib/scoring.ts`
- `lib/validation.ts`
- `lib/recommendations.ts`
- `public/assets/`

> Important: the live deployment's original source repository was not exposed by the public URL, so this is a clean functional reconstruction rather than a byte-for-byte copy of the original private source.
