import type { Profile } from '@/lib/scoring'; import {getRecommendations} from '@/lib/recommendations';
export default function RecommendationsSection({profile}:{profile:Profile}){return <section className="card score-card"><h2>Recommendations</h2><ul className="list">{getRecommendations(profile).map(x=><li key={x}>{x}</li>)}</ul></section>}
